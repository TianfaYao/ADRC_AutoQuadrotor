/*
 * AttitudeEKF_types.h
 *
 * Code generation for function 'AttitudeEKF'
 *
 * C source code generated on: Thu Aug 21 11:17:28 2014
 *
 */

#ifndef __ATTITUDEEKF_TYPES_H__
#define __ATTITUDEEKF_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* End of code generation (AttitudeEKF_types.h) */
