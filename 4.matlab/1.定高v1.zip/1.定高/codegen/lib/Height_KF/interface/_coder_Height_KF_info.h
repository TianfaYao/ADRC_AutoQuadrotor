/* 
 * File: _coder_Height_KF_info.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 27-Apr-2017 00:45:04 
 */

#ifndef ___CODER_HEIGHT_KF_INFO_H__
#define ___CODER_HEIGHT_KF_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_Height_KF_info.h 
 *  
 * [EOF] 
 */
