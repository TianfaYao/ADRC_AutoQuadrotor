/* 
 * File: Height_KF_types.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 27-Apr-2017 00:45:04 
 */

#ifndef __HEIGHT_KF_TYPES_H__
#define __HEIGHT_KF_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* 
 * File trailer for Height_KF_types.h 
 *  
 * [EOF] 
 */
